<?php
namespace Creche\Model;
/**
 * Created by PhpStorm.
 * User: geonidas
 * Date: 15/06/2019
 * Time: 09:59
 */




class Tuteur extends Db
{

}