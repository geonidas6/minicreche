<?php
/**
 * Created by PhpStorm.
 * User: geonidas
 * Date: 16/06/2019
 * Time: 08:53
 */

namespace Creche\Model;


class Tuteurenfant extends Db
{

}