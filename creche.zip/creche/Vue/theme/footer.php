<?php

$footer = "
<!-- Bootstrap core JavaScript-->
  <script src='Vue/theme/vendor/jquery/jquery.min.js'></script>
  <script src='vendor/bootstrap/js/bootstrap.bundle.min.js'></script>

  <!-- Core plugin JavaScript-->
  <script src='Vue/theme/vendor/jquery-easing/jquery.easing.min.js'></script>

  <!-- Custom scripts for all pages-->
  <script src='Vue/theme/theme/js/sb-admin-2.min.js'></script>
<script src='Vue/theme/Vendor/pnotify/dist/pnotify.js'></script>
<script src='Vue/theme/Vendor/pnotify/dist/pnotify.buttons.js'></script>
<script src='Vue/theme/Vendor/pnotify/dist/pnotify.nonblock.js'></script>
<script src='Vue/theme/Vendor/notify/notify.js'></script>
</body>

</html>

<script>
  
</script>

";

echo $footer;