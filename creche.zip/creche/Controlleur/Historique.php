<?php
/**
 * Created by PhpStorm.
 * User: geonidas
 * Date: 16/06/2019
 * Time: 08:52
 */

namespace Creche\Controlleur;


class Historique
{

}